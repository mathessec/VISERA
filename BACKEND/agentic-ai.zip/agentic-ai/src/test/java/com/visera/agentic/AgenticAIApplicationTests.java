package com.visera.agentic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgenticAIApplicationTests {

	@Test
	void contextLoads() {
	}

}


